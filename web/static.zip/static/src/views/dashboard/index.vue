<template>
  <div class="app-container">
    <div class="filter-container">
      {{msg}}
    </div>
  </div>
</template>

<script type="text/javascript">
  export default{
    data() {
      return {
        msg: 'gospider: 一个提供web任务管理界面的，让使用者只需关心页面规则的爬虫框架。'
      }
    }
  }
</script>
